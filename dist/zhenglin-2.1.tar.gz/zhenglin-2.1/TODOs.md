### PUT TODOs HERE, FUTURE WILL DO IT FOR YOU ###
1. ~~video.write()~~ Apr 30 2025
2. ~~video read~~ Apr 30 2025
3. Image class but C H W(should be H W C)