# pip install zhenglin

This package contains some off-the-shelves deep-learning networks implemented by pytorch.

- cycleGAN
- DDPM
- EDSR
- ESRGAN
- Noise2Void
- Pix2Pix
- RCAN
- Restormer
- RRDBNet
- SRGAN
- SWinIR
- U2Net
- UNet